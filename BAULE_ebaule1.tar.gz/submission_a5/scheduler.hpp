#ifndef SCHEDULER_HPP
#define SCHEDULER_HPP

#include "ssfs.hpp"

using namespace std;

void* SCH_run(void* vec);

#endif
